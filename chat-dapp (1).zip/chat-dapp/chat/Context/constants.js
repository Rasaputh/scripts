//POLYGON DEPLOY ADDRESS= 0xA68BDd8c7b77f53B0653AAc61C719f6397C8FA61

import chatApp from "./ChatApp.json";

// export const ChatAppAddress = "0x5FbDB2315678afecb367f032d93F642f64180aa3";
export const ChatAppAddress = "0xA68BDd8c7b77f53B0653AAc61C719f6397C8FA61";

export const ChatAppABI = chatApp.abi;
